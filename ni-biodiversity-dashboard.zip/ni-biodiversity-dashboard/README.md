# Northern Ireland Biodiversity Watch

A free, self-updating website tracking:
- **Recorded wildlife observations** in Northern Ireland, from [GBIF](https://www.gbif.org/)
- **GenBank reference sequences** for the same species, from [NCBI](https://www.ncbi.nlm.nih.gov/genbank/)

for a curated list of species relevant to AFBI/DAERA, with automatic trend flags and no server to maintain.

**How it works:** a scheduled GitHub Action re-queries GBIF and NCBI, computes trends, and commits the results as JSON. GitHub Pages serves the site as static files that read that JSON. There is no database and nothing to pay for.

---

## 1. Put this online (one-time setup, ~10 minutes)

You need a free GitHub account. If you don't have one, create one at [github.com/signup](https://github.com/signup) first.

1. **Create a new repository.** On github.com, click **+ → New repository**. Name it anything (e.g. `ni-biodiversity-dashboard`). Set it to **Public** (required for free unlimited GitHub Actions minutes and free GitHub Pages). Don't add a README/gitignore — leave it empty. Click **Create repository**.

2. **Upload these files.** On the new repo's page, click **Add file → Upload files**, then drag in *everything* from this project (keeping the folder structure: `scripts/`, `.github/workflows/`, `data/`, plus `index.html`, `style.css`, `app.js`, `species-config.json`, this `README.md`). Commit directly to `main`.
   - If you're comfortable with git instead, the usual `git init && git add . && git commit && git remote add origin ... && git push` works too.

3. **Allow the workflow to save data.** Go to the repo's **Settings → Actions → General**, scroll to **Workflow permissions**, select **Read and write permissions**, and click **Save**. (The workflow file also requests this itself, but this repo-level switch needs to allow it too.)

4. **Turn on GitHub Pages.** Go to **Settings → Pages**. Under "Build and deployment", set **Source** to **Deploy from a branch**, branch **main**, folder **/ (root)**. Save. GitHub will show your live URL (something like `https://yourusername.github.io/ni-biodiversity-dashboard/`) within a minute or two.

5. **Run the first data fetch now**, rather than waiting for the weekly schedule: go to the **Actions** tab → **Update biodiversity data** (left sidebar) → **Run workflow** → **Run workflow**. It takes a few minutes. Refresh your live URL once it finishes (green tick) and the dashboard will be populated.

That's it — from here it refreshes itself weekly with no further action needed.

---

## 2. Customising the species list

Edit `species-config.json` (either directly on github.com — click the file, then the pencil icon — or locally). Each entry:

```json
{ "scientificName": "Numenius arquata", "commonName": "Eurasian curlew", "category": "Priority species", "trackOccurrences": true, "trackSequences": true }
```

- `trackOccurrences: false` skips the GBIF call — use this for organisms that are diagnosed rather than field-recorded (e.g. bacteria).
- `invasiveAlert: true` makes the dashboard flag *any* NI record at all as a high-priority alert, rather than requiring a percentage change — appropriate for species that are currently absent or newly-arrived, where a single detection is the whole story (Asian hornet and European spruce bark beetle ship configured this way; adjust this list to match current DAERA biosecurity priorities, since I can't guarantee this is exhaustive or current).
- Adding species is free — it just adds a few more (fast) API calls to the weekly run. The 27-species starter list takes a few minutes to fully refresh; you could comfortably 3–4x it before needing to think about the run time.

Any edit takes effect on the next scheduled run, or immediately if you trigger the workflow manually (Actions tab → Run workflow).

---

## 3. Changing the refresh schedule

Edit the `cron:` line in `.github/workflows/update-data.yml`. It's currently weekly (Monday 03:00 UTC). For daily, change it to `'0 3 * * *'`. [crontab.guru](https://crontab.guru/) is useful for building other schedules. There's no need to go more often than daily — GBIF and NCBI data doesn't change that fast, and you said weekly-to-daily was the right cadence.

---

## 4. Design notes and known limitations (please read before relying on this operationally)

**Northern Ireland has no country code of its own**, so the GBIF query uses a bounding box (roughly 53.95–55.35°N, 8.20–5.30°W) combined with a `country=GB` filter. The box itself also covers parts of Donegal, Leitrim, Cavan, Monaghan and Louth in the Republic — the `country=GB` filter should exclude those (GBIF tags each record with the country it was recorded in, not just raw coordinates), but a small number of mis-tagged source records could still slip through either way. If you need this tightened further, swapping in a precise NI boundary polygon (e.g. from OSNI boundary data) in place of the bounding box in `scripts/fetch_gbif.py` is the way to do it.

**Observation counts reflect recording effort as well as species presence.** A flagged decline can mean fewer organisms, fewer people out looking, or both — the dashboard's wording deliberately says "recorded observations," never "population," for this reason. Treat every alert as a prompt to look closer, not a conclusion.

**GenBank sequence counts almost never fall** (records aren't usually retracted), so that side of the dashboard is framed as steady/accelerating/stalled rather than rising/declining — it's a proxy for research and sequencing attention on a species, not field abundance. This felt like a natural fit alongside your eDNA reference-database gap work, since it's effectively tracking the same reference-availability question from the GenBank side.

**Only complete calendar years feed the alert thresholds.** The current year-to-date is shown on every chart (as a lighter-shaded final bar) but deliberately excluded from the percentage-change maths, so a partial year is never mistaken for a decline. Thresholds (currently ±25%/±50% vs a rolling baseline) are constants at the top of `scripts/analyze_trends.py` if you want to retune them.

**I couldn't test the live API calls myself** while building this (my working environment has no internet access), only the surrounding logic — I checked GBIF's and NCBI's current API documentation directly and unit-tested the trend-classification code against fabricated sample data, but the very first real run is the first time these exact queries will actually hit GBIF/NCBI. If a species shows an error after the first run (visible in the Actions log, or as "No data yet" on its card), it's most likely a taxonomic name mismatch — GBIF's or NCBI's own taxonomy occasionally uses a different accepted name than the one in `species-config.json`. Come back and paste me the Actions log output and I'll fix it.

---

## 5. File map

```
index.html, style.css, app.js     the site itself (static, no build step)
species-config.json               the tracked species list + NI bounding box — edit freely
data/occurrences.json             GBIF results (rewritten each run)
data/sequences.json               NCBI results (rewritten each run)
data/summary.json                 computed trends + alerts the frontend reads (rewritten each run)
scripts/fetch_gbif.py             queries GBIF
scripts/fetch_ncbi.py             queries NCBI
scripts/analyze_trends.py         turns the above into trend labels + alerts
.github/workflows/update-data.yml the schedule that runs the three scripts and commits the result
```

## 6. Cost

£0. Public GitHub repos get unlimited free Actions minutes and free Pages hosting; GBIF and NCBI are free public APIs (NCBI politely asks non-key users to stay under 3 requests/second, which the scripts respect with built-in pauses).
